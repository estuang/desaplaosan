<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Pengaduan;

class PengaduanController extends Controller
{
    // Tampilkan semua pengaduan
    public function index()
    {
        $pengaduans = Pengaduan::orderBy('created_at', 'desc')->get();
        $title = 'Pengaduan';
        return view('admin.pengaduan.index', compact('pengaduans', 'title'));
    }

    // Tampilkan form update (modal di view)
    public function edit($id)
    {
        $pengaduan = Pengaduan::findOrFail($id);
        return view('admin.pengaduan.index', compact('pengaduan'));
    }

    // Update status pengaduan
    public function update(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:menunggu,diproses,disetujui,ditolak',
        ]);
        $pengaduan = Pengaduan::findOrFail($id);
        $pengaduan->status = $request->status;
        $pengaduan->save();
        return redirect()->back()->with('success', 'Pengaduan berhasil dikirim!');
    }
}
