
<?php $__env->startSection('adminContent'); ?>
    <main class="col-md-0 ms-sm-auto col-lg-10 px-md-4 mt-3">
        <div>
        </div>
        <div>
            <h2>Daftar Semua Pengaduan</h2>
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Judul</th>
                        <th>Isi</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>Foto</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pengaduans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($p->nama); ?></td>
                            <td><?php echo e($p->judul); ?></td>
                            <td><?php echo e($p->isi); ?></td>
                            <td>
                                <?php if($p->status == 'menunggu'): ?>
                                    <span class="badge bg-warning text-dark">Menunggu</span>
                                <?php elseif($p->status == 'diproses'): ?>
                                    <span class="badge bg-primary">Diproses</span>
                                <?php elseif($p->status == 'disetujui'): ?>
                                    <span class="badge bg-success">Disetujui</span>
                                <?php elseif($p->status == 'ditolak'): ?>
                                    <span class="badge bg-danger">Ditolak</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e($p->status); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($p->created_at ? $p->created_at->format('d-m-Y') : '-'); ?></td>
                            <td>
                                <?php if($p->foto): ?>
                                    <img src="<?php echo e(asset('storage/' . $p->foto)); ?>" alt="Bukti" width="80">
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                    data-bs-target="#editModal<?php echo e($p->id); ?>">Ubah Status</button>
                            </td>
                        </tr>
                        <!-- Modal Edit Status -->
                        <div class="modal fade" id="editModal<?php echo e($p->id); ?>" tabindex="-1"
                            aria-labelledby="editModalLabel<?php echo e($p->id); ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editModalLabel<?php echo e($p->id); ?>">Ubah Status
                                            Pengaduan
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <form action="<?php echo e(route('admin.pengaduan.update', $p->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label for="status" class="form-label">Status</label>
                                                <select class="form-select" name="status" id="status" required>
                                                    <option value="menunggu"
                                                        <?php echo e($p->status == 'menunggu' ? 'selected' : ''); ?>>Menunggu</option>
                                                    <option value="diproses"
                                                        <?php echo e($p->status == 'diproses' ? 'selected' : ''); ?>>Diproses</option>
                                                    <option value="disetujui"
                                                        <?php echo e($p->status == 'disetujui' ? 'selected' : ''); ?>>Disetujui
                                                    </option>
                                                    <option value="ditolak"
                                                        <?php echo e($p->status == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('./layout/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek_plaosan\projek_plaosan\resources\views/admin/pengaduan/index.blade.php ENDPATH**/ ?>