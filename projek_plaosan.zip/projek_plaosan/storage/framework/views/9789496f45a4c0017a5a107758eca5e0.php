

<?php $__env->startSection('adminContent'); ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo e($title); ?></h1>
    </div>
    <div class="card" style="width: 100%; height: 100%; background-color: white; padding: 20px">
        <?php if(session()->has('successUpdatedMasyarakat')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successUpdatedMasyarakat')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session()->has('successCreatedPenduduk')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successCreatedPenduduk')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('success')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session()->has('successDeletedMasyarakat')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successDeletedMasyarakat')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session()->has('successDeletedAllData')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successDeletedAllData')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>


        <div>
            <div class="d-flex">

                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#cretaeDataMasyarakat" style="margin-right: 15px">Tambah Data Kematian</button>
                <form action="/surat-keterangan-kematian" method="GET" style="margin-left: 40%">

                    <input type="text" id="cari" name="cari" placeholder="Cari NIK/No KK/Nama">
                    <button type="submit" class="btn btn-success">Cari</button>
                </form>
            </div>

            <!-- Modal create-->
            <div class="modal fade" id="cretaeDataMasyarakat" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="cretaeDataMasyarakatLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="cretaeDataMasyarakatLabel">Tambah Data Surat Keterangan Kematian</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form action="/surat-keterangan-kematian/save" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">

                                <div class="mb-3">
                                    <label for="tgl_regis_mati" class="form-label"><b>TGL Regis Kematian</b></label>

                                    <input type="date" name="tgl_regis_mati" id="tgl_regis_mati" class="form-control <?php $__errorArgs = ['tgl_regis_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('tgl_regis_mati')); ?>" autocomplete="off" placeholder="Input Tanggal Regis Lahir">

                                    <?php $__errorArgs = ['tgl_regis_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <p style="text-align: left"><?php echo e($message); ?></p>
                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="no_kk" class="form-label"><b>NO KK</b></label>

                                    <select class="form-select" name="no_kk" id="no_kk">
                                        <option name="no_kk" id="no_kk" value="" selected>Silakan Pilih NO KK</option>
                                        <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option name="no_kk" id="no_kk" value="<?php echo e($penduduk->no_kk); ?>"><?php echo e($penduduk->no_kk); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="nama_kepala_keluarga" class="form-label"><b>Nama Kepala Keluarga</b></label>

                                    <select class="form-select" name="nama_kepala_keluarga" id="nama_kepala_keluarga">
                                        <option name="nama_kepala_keluarga" id="nama_kepala_keluarga" value="" selected>Silakan Pilih Kepala Keluarga</option>
                                        <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option name="nama_kepala_keluarga" id="nama_kepala_keluarga" value="<?php echo e($kep->nama); ?>"><?php echo e($kep->nik); ?> | <?php echo e($kep->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="nik_mati" class="form-label"><b>NIK Jenazah</b></label>

                                    <select class="form-select" name="nik_mati" id="nik_mati">
                                        <option name="nik_mati" id="nik_mati" value="" selected>Silakan Pilih NIK Jenazah</option>
                                        <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option name="nik_mati" id="nik_mati" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group row mb-3">


                                    <div class="mb-3">
                                        <label for="tgl_mati" class="form-label"><b>Tanggal Kematian</b></label>

                                        <input type="date" name="tgl_mati" id="tgl_mati" class="form-control <?php $__errorArgs = ['tgl_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('tgl_mati')); ?>" autocomplete="off" placeholder="Input Tanggal Mati">

                                        <?php $__errorArgs = ['tgl_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="pukul_mati" class="form-label"><b>Jam Kematian</b></label>

                                        <input type="time" name="pukul_mati" id="pukul_mati" class="form-control <?php $__errorArgs = ['pukul_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('pukul_mati')); ?>" autocomplete="off" placeholder="Input Jam Kematian">

                                        <?php $__errorArgs = ['pukul_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group row mb-3">
                                        <div class="mb-3">
                                            <label for="sebab" class="form-label"><b>Sebab Kematian</b></label>

                                            <select class="form-select" name="sebab" id="sebab">
                                                <option name="sebab" id="sebab" value="" selected>Silakan Pilih Sebab Kematian</option>
                                                <option name="sebab" id="sebab" value="kecelakaan">Kecelakaan</option>
                                                <option name="sebab" id="sebab" value="Sakit">Sakit</option>
                                                <option name="sebab" id="sebab" value="Lain-Lain">Lain-Lain</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="tempat_mati" class="form-label"><b>Tempat Kematian</b></label>

                                            <select class="form-select" name="tempat_mati" id="tempat_mati">
                                                <option name="tempat_mati" id="tempat_mati" value="" selected>Silakan Pilih Tempat Kematian</option>
                                                <option name="tempat_mati" id="tempat_mati" value="Rumah">Rumah</option>
                                                <option name="tempat_mati" id="tempat_mati" value="Jalan">Jalan</option>
                                                <option name="tempat_mati" id="tempat_mati" value="Rumah Sakit">Rumah Sakit</option>
                                                <option name="tempat_mati" id="tempat_mati" value="Lain-Lain">Lain-Lain</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="yang_menerangkan" class="form-label"><b>Yang Menerangkan</b></label>

                                            <select class="form-select" name="yang_menerangkan" id="yang_menerangkan">
                                                <option name="yang_menerangkan" id="yang_menerangkan" value="" selected>Silakan Pilih Yang Menerangkan</option>
                                                <option name="yang_menerangkan" id="yang_menerangkan" value="Keluarga">Keluarga</option>
                                                <option name="yang_menerangkan" id="yang_menerangkan" value="Teman">Teman</option>
                                                <option name="yang_menerangkan" id="yang_menerangkan" value="Tetangga">Tetangga</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="nik_ibu" class="form-label"><b>NIK Ibu</b></label>

                                        <select class="form-select" name="nik_ibu" id="nik_ibu">
                                            <option name="nik_ibu" id="nik_ibu" value="" selected>Silakan Pilih NIK Ibu</option>
                                            <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="nik_ibu" id="nik_ibu" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="nik_ayah" class="form-label"><b>NIK Ayah</b></label>

                                        <select class="form-select" name="nik_ayah" id="nik_ayah">
                                            <option name="nik_ayah" id="nik_ayah" value="" selected>Silakan Pilih NIK Ayah</option>
                                            <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="nik_ayah" id="nik_ayah" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="nik_pelapor" class="form-label"><b>NIK Pelapor</b></label>

                                        <select class="form-select" name="nik_pelapor" id="nik_pelapor">
                                            <option name="nik_pelapor" id="nik_pelapor" value="" selected>Silakan Pilih NIK Pelapor</option>
                                            <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="nik_pelapor" id="nik_pelapor" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="nik_saksisatu" class="form-label"><b>NIK Saksi Satu</b></label>

                                        <select class="form-select" name="nik_saksisatu" id="nik_saksisatu">
                                            <option name="nik_saksisatu" id="nik_saksisatu" value="" selected>Silakan Pilih NIK Saksi Satu</option>
                                            <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="nik_saksisatu" id="nik_saksisatu" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="nik_saksidua" class="form-label"><b>NIK Saksi Dua</b></label>

                                        <select class="form-select" name="nik_saksidua" id="nik_saksidua">
                                            <option name="nik_saksidua" id="nik_saksidua" value="" selected>Silakan Pilih NIK Saksi Dua</option>
                                            <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="nik_saksidua" id="nik_saksidua" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Modal delete all-->
            <div class="modal fade" id="deleteAllData" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="deleteAllDataLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="deleteAllDataLabel">Hapus Seluruh Data Bayi</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <div class="mb-3">
                                <p><b>Apakah anda yakin untuk menghapus seluruh data bayi? pastikan anda telah meng-export data untuk menanggulangi kesalahan</b></p>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                            <a href="deleteAllMasyarakat"><button type="submit" class="btn btn-primary">Delete</button></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal export excel-->
            <div class="modal fade" id="exportExcel" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exportExcelLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exportExcelLabel">Export Seluruh Data Masyarakat</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <div class="mb-3">
                                <p><b>Apakah anda yakin untuk meng-export seluruh data masyarakat? pastikan data telah benar untuk menanggulangi kesalahan</b></p>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                            <a href="masyarakatImport"><button class="btn btn-primary">Export</button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table" style="text-align: left; color: black">
                <tr>
                    <th>No</th>
                    <th>TGL Regis</th>
                    <th>Nama</th>
                    <th>NIK</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th>Tempat Mati</th>
                    <th>TGL Kematian</th>
                    <th style="text-align: center">Lampiran</th>
                    <th style="text-align: center">Verifikasi</th>
                    <th style="text-align: center">Cetak</th>
                </tr>
                <?php $__currentLoopData = $mati; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="width: 100%">
                    <td style="vertical-align: middle; width: 5%; "><?php echo e($index + $mati->firstItem()); ?></td>
                    <td style="vertical-align: middle;  "><?php echo e($item->tgl_regis_mati); ?></td>
                    <td style="vertical-align: middle;  "><?php echo e($item->nama_mati); ?></td>
                    <td style="vertical-align: middle;  "><?php echo substr($item->nik_mati,0,4). str_repeat('*', 16); ?></td>
                    <td style="vertical-align: middle;  "><?php echo e($item->jenis_kelamin); ?></td>
                    <td style="vertical-align: middle;  "><?php echo e($item->alamat_mati); ?></td>
                    <td style="vertical-align: middle;  "><?php echo e($item->tempat_mati); ?></td>
                    <td style="vertical-align: middle;  "><?php echo e($item->tgl_mati); ?></td>
                    <td style="text-align: center;  ">
                        <a href="<?php echo e(route('surat-keterangan-kematian/lampiran/show',$item->nik_mati)); ?>"><button class="btn btn-success"><i class="bi bi-eye-fill"></i></button></a>
                        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#cretaeLampiran<?php echo e($item->nik_mati); ?>"><i class="bi bi-plus-square-fill"></i></button>
                        <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#destroyLampiran<?php echo e($item->nik_mati); ?>"><i class="bi bi-trash"></i></button>
                    </td>
                    <td style="text-align: center;  ">
                        <?php if($item->verifikasi=="Belum Verifikasi"): ?>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#verifikasibayi<?php echo e($item->nik_mati); ?>">Verifikasi</button>
                        <?php else: ?>
                        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#batalverifikasi<?php echo e($item->nik_mati); ?>" disabled>Terverifikasi</button>
                        <?php endif; ?>
                    </td>
                    <td style="text-align: center;  ">
                        <a href="<?php echo e(route('surat-keterangan-kematian/pdflurah',$item->nik_mati)); ?>" class="btn btn-success" target="_blank">PDF</a>
                    </td>
                </tr>

                <!-- Modal verifikasi-->
                <div class="modal fade" id="verifikasibayi<?php echo e($item->nik_mati); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="staticBackdropLabel">Verifikasi Data Kematian</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>Apakah anda yakin untuk memverifikasi data <b><?php echo e($item->nama_mati); ?></b></p>
                                <p>Perikas Kembali Data Sebelum Melakukan Verifikasi, Data Yang Sudah Diverifikasi Tidak Bisa Diubah Lagi</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                <form action="<?php echo e(route('surat-keterangan-kematian', $item->nik_mati)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" id="verifikasi" name="verifikasi" value="Sudah Verifikasi" hidden>
                                    <input type="text" id="sts_penduduk" name="sts_penduduk" value="Meninggal" hidden>
                                    <button type="submit" class="btn btn-success">Verifikasi</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal batal verifikasi-->
                <div class="modal fade" id="batalverifikasi<?php echo e($item->nik_mati); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="staticBackdropLabel">Verifikasi Data Kelahiran</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>Apakah anda yakin untuk membatalkan verifikasi data <b><?php echo e($item->nama_mati); ?></b></p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                <form action="<?php echo e(route('surat-keterangan-kematian', $item->nik_mati)); ?>" method="post">
                                    <?php echo method_field('post'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="verifikasi" value="Belum Verifikasi" value="Belum Verifikasi" hidden>
                                    <button type="submit" class="btn btn-danger">Batalkan Verifikasi</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal delete lampiran-->
                <div class="modal fade" id="destroyLampiran<?php echo e($item->nik_mati); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="destroyLampiranLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="destroyLampiranLabel">Delete Lampiran</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>Apakah anda yakin untuk menghapus lampiran dari <b><?php echo e($item->nama); ?></b></p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                <form action="<?php echo e(route('surat-keterangan-kematian/lampiran/destroy', $item->nik_mati)); ?>" method="post">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger">Deleted</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal edit-->
                <div class="modal fade" id="editbayi<?php echo e($item->nik_mati); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="editDataMasyarakatLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="editDataMasyarakatLabel">Edit Data Penduduk</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('surat-keterangan-kematian',$item->nik_mati)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">

                                    <div class="mb-3">
                                        <label for="tgl_regis_mati" class="form-label"><b>TGL Regis Kematian</b></label>

                                        <input type="date" name="tgl_regis_mati" id="tgl_regis_mati" class="form-control <?php $__errorArgs = ['tgl_regis_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('tgl_regis_mati')); ?>" autocomplete="off" placeholder="Input Tanggal Regis Lahir">

                                        <?php $__errorArgs = ['tgl_regis_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="no_kk" class="form-label"><b>NO KK</b></label>

                                        <input type="text" name="no_kk" id="no_kk" class="form-control <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('no_kk')); ?>" autocomplete="off" placeholder="Input NO KK">

                                        <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="nama_kepala_keluarga" class="form-label"><b>Nama Kepala Keluarga</b></label>

                                        <input type="text" name="nama_kepala_keluarga" id="nama_kepala_keluarga" class="form-control <?php $__errorArgs = ['nama_kepala_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('nama_kepala_keluarga')); ?>" autocomplete="off" placeholder="Input Nama Kepala Keluarga">

                                        <?php $__errorArgs = ['nama_kepala_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="nik_mati" class="form-label"><b>Nik Mati</b></label>

                                        <input type="text" name="nik_mati" id="nik_mati" class="form-control <?php $__errorArgs = ['nik_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('nik_mati')); ?>" autocomplete="off" placeholder="Input NIK Mati">

                                        <?php $__errorArgs = ['nik_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group row mb-3">
                                        <div class="col-sm-4">
                                            <label for="anak_ke" class="form-label"><b>Anak Ke</b></label>

                                            <input type="text" name="anak_ke" id="anak_ke" class="form-control <?php $__errorArgs = ['anak_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('anak_ke')); ?>" autocomplete="off" placeholder="Input Anak Ke">

                                            <?php $__errorArgs = ['anak_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-4">
                                            <label for="tgl_mati" class="form-label"><b>Tanggal Mati</b></label>

                                            <input type="date" name="tgl_mati" id="tgl_mati" class="form-control <?php $__errorArgs = ['tgl_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('tgl_mati')); ?>" autocomplete="off" placeholder="Input Tanggal Mati">

                                            <?php $__errorArgs = ['tgl_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-4">
                                            <label for="pukul_mati" class="form-label"><b>Jam Kematian</b></label>

                                            <input type="time" name="pukul_mati" id="pukul_mati" class="form-control <?php $__errorArgs = ['pukul_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('pukul_mati')); ?>" autocomplete="off" placeholder="Input Jam Kematian">

                                            <?php $__errorArgs = ['pukul_mati'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-group row mb-3">
                                        <div class="mb-3">
                                            <label for="sebab" class="form-label"><b>Sebab Kematian</b></label>

                                            <select class="form-select" name="sebab" id="sebab">
                                                <option name="sebab" id="sebab" value="" selected>Silakan Pilih Sebab Kematian</option>
                                                <option name="sebab" id="sebab" value="kecelakaan">Kecelakaan</option>
                                                <option name="sebab" id="sebab" value="Sakit">Sakit</option>
                                                <option name="sebab" id="sebab" value="Lain-Lain">Lain-Lain</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="tempat_mati" class="form-label"><b>Tempat Kematian</b></label>

                                            <select class="form-select" name="tempat_mati" id="tempat_mati">
                                                <option name="tempat_mati" id="tempat_mati" value="" selected>Silakan Pilih Tempat Kematian</option>
                                                <option name="tempat_mati" id="tempat_mati" value="Rumah">Rumah</option>
                                                <option name="tempat_mati" id="tempat_mati" value="Jalan">Jalan</option>
                                                <option name="tempat_mati" id="tempat_mati" value="Rumah Sakit">Rumah Sakit</option>
                                                <option name="tempat_mati" id="tempat_mati" value="Lain-Lain">Lain-Lain</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="alamat" class="form-label"><b>Alamat </b></label>

                                            <input type="text" name="alamat" id="alamat" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('alamat')); ?>" autocomplete="off" placeholder="Input Alamat">

                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label for="yang_menerangkan" class="form-label"><b>Yang Menerangkan</b></label>

                                            <select class="form-select" name="yang_menerangkan" id="yang_menerangkan">
                                                <option name="yang_menerangkan" id="yang_menerangkan" value="" selected>Silakan Pilih Yang Menerangkan</option>
                                                <option name="yang_menerangkan" id="yang_menerangkan" value="Keluarga">Keluarga</option>
                                                <option name="yang_menerangkan" id="yang_menerangkan" value="Teman">Teman</option>
                                                <option name="yang_menerangkan" id="yang_menerangkan" value="Tetangga">Tetangga</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="nik_ibu" class="form-label"><b>NIK Ibu</b></label>

                                        <select class="form-select" name="nik_ibu" id="nik_ibu">
                                            <option name="nik_ibu" id="nik_ibu" value="" selected>Silakan Pilih NIK Ibu</option>
                                            <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="nik_ibu" id="nik_ibu" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="nik_ayah" class="form-label"><b>NIK Ayah</b></label>

                                        <select class="form-select" name="nik_ayah" id="nik_ayah">
                                            <option name="nik_ayah" id="nik_ayah" value="" selected>Silakan Pilih NIK Ayah</option>
                                            <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="nik_ayah" id="nik_ayah" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="nik_pelapor" class="form-label"><b>NIK</b></label>

                                        <select class="form-select" name="nik" id="nik">
                                            <option name="nik_pelapor" id="nik_pelapor" value="" selected>Silakan Pilih NIK Pelapor</option>
                                            <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="nik_pelapor" id="nik_pelapor" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="nik_saksisatu" class="form-label"><b>NIK Saksi Satu</b></label>

                                        <select class="form-select" name="nik_saksisatu" id="nik_saksisatu">
                                            <option name="nik_saksisatu" id="nik_saksisatu" value="" selected>Silakan Pilih NIK Saksi Satu</option>
                                            <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="nik_saksisatu" id="nik_saksisatu" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="nik_saksidua" class="form-label"><b>NIK Saksi Dua</b></label>

                                        <select class="form-select" name="nik_saksidua" id="nik_saksidua">
                                            <option name="nik_saksidua" id="nik" value="" selected>Silakan Pilih NIK Saksi</option>
                                            <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="nik_saksidua" id="nik_saksidua" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>

                <!-- Modal Create Lampiran-->
                <div class="modal fade" id="cretaeLampiran<?php echo e($item->nik_mati); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="cretaeLampiranLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="cretaeLampiranLabel">Tambah Lampiran Surat Keterangan Kematian</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <span class="modal-title fs-6 text-center" id="cretaeLampiranLabel">Upload dokumen kelengkapan, pastikan file berupa (jpg/pdf) dengan ukuran masksmal 2MB/file</span>
                            <form id="lampiranForm" action="<?php echo e(route('surat-keterangan-kematian/lampiran/store',$item->nik_mati)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo method_field('POST'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">

                                    <div class="mb-3">
                                        <label for="pengantar_rt" class="form-label">Surat Pengantar RT</label>
                                        <input class="form-control" type="file" id="pengantar_rt" name="pengantar_rt">
                                        <?php $__errorArgs = ['pengantar_rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="pengantar_dokter" class="form-label">Surat Keterangan Dokter/Pramedis</label>
                                        <input class="form-control" type="file" id="pengantar_dokter" name="pengantar_dokter">
                                        <?php $__errorArgs = ['pengantar_dokter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="kk" class="form-label">Kartu Keluarga</label>
                                        <input class="form-control" type="file" id="kk" name="kk">
                                        <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ktp_jenazah" class="form-label">KTP Jenazah</label>
                                        <input class="form-control" type="file" id="ktp_jenazah" name="ktp_jenazah">
                                        <?php $__errorArgs = ['ktp_jenazah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ktp_pelapor" class="form-label">KTP Pelapor</label>
                                        <input class="form-control" type="file" id="ktp_pelapor" name="ktp_pelapor">
                                        <?php $__errorArgs = ['ktp_pelapor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ktp_saksi" class="form-label">KTP Saksi 1</label>
                                        <input class="form-control" type="file" id="ktp_saksi" name="ktp_saksi">
                                        <?php $__errorArgs = ['ktp_saksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ktp_saksi2" class="form-label">KTP Saksi 2</label>
                                        <input class="form-control" type="file" id="ktp_saksi2" name="ktp_saksi2">
                                        <?php $__errorArgs = ['ktp_saksi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="d-flex justify-content-between mb-3">
                <?php echo e($mati->links('layout.pagination')); ?>

            </div>
        </div>

    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-plaosan-ta\resources\views/adminDashboard/SuratKetKematian.blade.php ENDPATH**/ ?>