

<?php $__env->startSection('adminContent'); ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo e($title); ?></h1>
    </div>
    <div class="card" style="width: 100%; height: 100%; background-color: white; padding: 20px">
        <?php if(session()->has('successUpdatedAcount')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successUpdatedAcount')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session()->has('successDeletedOtherAcount')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successDeletedOtherAcount')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session()->has('successCreatedOtherAcount')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successCreatedOtherAcount')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>


        <script>
            function password_show_hide() {
                var x = document.getElementById("password");
                var show_eye = document.getElementById("show_eye");
                var hide_eye = document.getElementById("hide_eye");
                hide_eye.classList.remove("d-none");
                if (x.type === "password") {
                    x.type = "text";
                    show_eye.style.display = "none";
                    hide_eye.style.display = "block";
                } else {
                    x.type = "password";
                    show_eye.style.display = "block";
                    hide_eye.style.display = "none";
                }
            }

            function password_show_hideAdmin() {
                var x = document.getElementById("passwordAdmin");
                var show_eye = document.getElementById("show_eyeAdmin");
                var hide_eye = document.getElementById("hide_eyeAdmin");
                hide_eye.classList.remove("d-none");
                if (x.type === "password") {
                    x.type = "text";
                    show_eye.style.display = "none";
                    hide_eye.style.display = "block";
                } else {
                    x.type = "password";
                    show_eye.style.display = "block";
                    hide_eye.style.display = "none";
                }
            }
        </script>

        <div class="py-4">
            <div class="mb-4">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createdAcount">Created Acount</button>

                
                <div class="modal fade" id="createdAcount" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="createdAcountLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="createdAcountLabel">Created Acount</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>

                            <form action="/other-account/store" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="name" class="form-label"><b>Nama User</b></label>

                                        <input type="text" name="name" id="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus required value="<?php echo e(old('name')); ?>" placeholder="Input your name">

                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="userName" class="form-label"><b>UserName</b></label>

                                        <input type="text" name="userName" id="userName" class="form-control <?php $__errorArgs = ['userName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus required value="<?php echo e(old('userName')); ?>" placeholder="Input your userName">

                                        <?php $__errorArgs = ['userName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="role" class="form-label"><b>Status Akun</b></label>

                                        <select class="form-select" name="role" id="role">
                                            <option value="" selected>Pilih status akun</option>
                                            <option value="Staff">Staff</option>
                                            <option value="Masyarakat">Masyarakat</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">

                                        <label for="password" class="form-label"><b>Password</b></label>
                                        <p class="text-muted" style="font-size: 11px; margin-top: -8px;">Password terdiri dari minimal 8 karakter dan maksimal 15 karakter </p>
                                        <p class="text-muted" style="font-size: 11px; margin-top: -8px;">(Huruf besar, Huruf kecil, Angka)</p>

                                        <div class="input-group mb-3">
                                            <input name="password" type="password" class="input form-control" id="password" placeholder="password" required="true" aria-label="password" aria-describedby="basic-addon1" />

                                            <div class="input-group-append">
                                                <span class="input-group-text" onclick="password_show_hide();" style="height: 39px">
                                                    <i class="fas fa-eye" id="show_eye"></i>
                                                    <i class="fas fa-eye-slash d-none" id="hide_eye"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Created</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <table class="table mb-5" style="text-align: left; color: black">
                <div style="background-color: #006029; color: whitesmoke; width: 100%">
                    <h6 class="py-2" style="font-family: 'Raleway', sans-serif; text-align: center;">Daftar Akun</h6>
                </div>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Status</th>
                    <th>Last Updated</th>
                    <th style="text-align: center">Action</th>
                </tr>
                <?php $i = 1 ?>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="width: 100%">
                    <td style="vertical-align: middle; width: 5%; "><?php echo e($i++); ?></td>
                    <td style="vertical-align: middle; width: 30%; text-transform: capitalize"><?php echo e($item->name); ?></td>
                    <td style="vertical-align: middle;"><?php echo e($item->userName); ?></td>
                    <td style="vertical-align: middle; text-transform: capitalize "><?php echo e($item->role); ?></td>
                    <td style="vertical-align: middle;  "><?php echo e($item->updated_at); ?></td>
                    <td style="text-align: center;  ">
                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editAcount<?php echo e($item->id); ?>">Edit</button>
                        <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#admin<?php echo e($item->id); ?>">Hapus</button>
                    </td>
                </tr>

                <!-- Modal delete-->
                <div class="modal fade" id="admin<?php echo e($item->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="adminLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="adminLabel">Delete <?php echo e($item->title); ?></h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>Apakah anda yakin untuk menghapus acount <b><?php echo e($item->status); ?> <?php echo e($item->name); ?></b></p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                <form action="/other-account/delete/<?php echo e($item->id); ?>" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger">Deleted</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="modal fade" id="editAcount<?php echo e($item->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="editAcountLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="editAcountLabel">Edit Acount <?php echo e($item->name); ?></h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>

                            <form action="/other-account/update/<?php echo e($item->id); ?>" method="POST">
                                <?php echo method_field('POST'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="name" class="form-label"><b>Nama User</b></label>

                                        <input type="text" name="name" id="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus required value="<?php echo e(old('name', $item->name)); ?>" placeholder="Input your name">

                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="userName" class="form-label"><b>UserName</b></label>

                                        <input type="text" name="userName" id="userName" class="form-control <?php $__errorArgs = ['userName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus required value="<?php echo e(old('userName', $item->userName)); ?>" placeholder="Input your userName">

                                        <?php $__errorArgs = ['userName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <p style="text-align: left"><?php echo e($message); ?></p>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mb-3">
                                        <label for="role" class="form-label"><b>Status Akun</b></label>

                                        <select class="form-select" name="role" id="role">
                                            <option value="<?php echo e($item->role); ?>" selected><?php echo e($item->role); ?></option>
                                            <option value="Staff">Staff</option>
                                            <option value="Masyarakat">Masyarakat</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">

                                        <label for="password" class="form-label"><b>Password</b></label>
                                        <p class="text-muted" style="font-size: 11px; margin-top: -8px;">Password terdiri dari minimal 8 karakter dan maksimal 15 karakter </p>
                                        <p class="text-muted" style="font-size: 11px; margin-top: -8px;">(Huruf besar, Huruf kecil, Angka)</p>

                                        <div class="input-group mb-3">
                                            <input name="password" type="password" class="input form-control  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="passwordAdmin" placeholder="password" aria-label="password" aria-describedby="basic-addon1" />

                                            <div class="input-group-append">
                                                <span class="input-group-text" onclick="password_show_hide();" style="height: 39px">
                                                    <i class="fas fa-eye" id="show_eyeAdmin"></i>
                                                    <i class="fas fa-eye-slash d-none" id="hide_eyeAdmin"></i>
                                                </span>
                                            </div>
                                        </div>

                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p style="text-align: left"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Updated</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>



                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        </div>

    </div>
</main>
<script>
    function password_show_hide() {
        var x = document.getElementById("password");
        var show_eye = document.getElementById("show_eye");
        var hide_eye = document.getElementById("hide_eye");
        hide_eye.classList.remove("d-none");
        if (x.type === "password") {
            x.type = "text";
            show_eye.style.display = "none";
            hide_eye.style.display = "block";
        } else {
            x.type = "password";
            show_eye.style.display = "block";
            hide_eye.style.display = "none";
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web-desa-plaosan-ta-copy\resources\views/adminDashboard/otherAcount.blade.php ENDPATH**/ ?>