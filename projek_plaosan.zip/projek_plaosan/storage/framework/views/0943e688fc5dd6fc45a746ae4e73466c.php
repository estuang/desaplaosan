


<?php $__env->startSection('adminContent'); ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Daftar Pengajuan Surat Keterangan</h1>
        </div>
        <div class="card" style="width: 100%; background-color: white; padding: 20px">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" style="text-align: left; color: black">
                    <thead class="thead-light">
                        <tr>
                            <th>No</th>
                            <th>Nama Warga</th>
                            <th>Kategori</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->user->nama ?? '-'); ?></td>
                                <td><?php echo e($item->kategori); ?></td>
                                <td>
                                    <?php if($item->status_verifikasi == 'diterima'): ?>
                                        <span class="badge bg-success">Diterima</span>
                                    <?php elseif($item->status_verifikasi == 'ditolak'): ?>
                                        <span class="badge bg-danger">Ditolak</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <!-- Tombol Detail User -->
                                    <?php if($item->user && $item->user->penduduk): ?>
                                        <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#detailUserModal<?php echo e($item->id); ?>">
                                            Detail User
                                        </button>
                                    <?php endif; ?>
                                    <!-- Tombol Validasi -->
                                    <?php if($item->status_verifikasi == 'pending'): ?>
                                        <a href="<?php echo e(route('admin.surat-keterangan.validasiForm', $item->id)); ?>"
                                            class="btn btn-sm btn-primary mb-1">
                                            Validasi
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            
            <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->user && $item->user->penduduk): ?>
                    <div class="modal fade" id="detailUserModal<?php echo e($item->id); ?>" tabindex="-1"
                        aria-labelledby="detailUserModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="detailUserModalLabel<?php echo e($item->id); ?>">
                                        Detail Data Penduduk</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <table class="table table-borderless">
                                        <tr>
                                            <th>Nama Lengkap</th>
                                            <td><?php echo e($item->user->penduduk->nama); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Tempat dan Tanggal Lahir</th>
                                            <td><?php echo e($item->user->penduduk->tempat_lahir ?? '-'); ?>,
                                                <?php echo e($item->user->penduduk->tanggal_lahir ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>NIK</th>
                                            <td><?php echo e($item->user->penduduk->nik); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Jenis Kelamin</th>
                                            <td><?php echo e($item->user->penduduk->jk ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Pekerjaan</th>
                                            <td><?php echo e($item->user->penduduk->pekerjaan ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Status Perkawinan</th>
                                            <td><?php echo e($item->user->penduduk->sts_kawin ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Alamat Lengkap</th>
                                            <td><?php echo e($item->user->alamat ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Kewarganegaraan</th>
                                            <td><?php echo e($item->user->penduduk->kebangsaan ?? '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Agama</th>
                                            <td><?php echo e($item->user->penduduk->agama ?? '-'); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web-desa-plaosan-ta-copy-Copyfix\resources\views/adminDashboard/surat-keterangan/index.blade.php ENDPATH**/ ?>