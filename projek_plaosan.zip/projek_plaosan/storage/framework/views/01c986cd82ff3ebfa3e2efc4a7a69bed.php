

<?php $__env->startSection('wargaContent'); ?>

<div class="text-center mt-5">
  <h3>Selamat Datang di Website</h3> 
  <h3>Sistem Manajemen Layanan Masyarakat Desa Plaosan</h3>
  <a href="/logout" class="btn btn-danger mt-3">Log Out</a>
</div>


  <div class="container">
    <div class="button-grid">
      <!-- Tombol Pendataan -->
      <a href="<?php echo e(url('/warga')); ?>" class="box-button blue">Pendataan</a>

      <!-- Tombol Pengaduan -->
      <a href="<?php echo e(url('/pengaduan')); ?>" class="box-button blue">Pengaduan</a>
    </div>
  </div>
  
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/mainWarga2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-plaosan-ta\resources\views/wargaDashboard/pilih.blade.php ENDPATH**/ ?>