

<?php $__env->startSection('adminContent'); ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo e($title); ?></h1>
    </div>
    <div class="card" style="width: 100%; height: 100%; background-color: white; padding: 20px">
        <!-- Modal Show Lampiran-->
        <div class="container">

            <h3>Data Lampiran Kosong, Silahkan Unggah/Upload Lampiran</h3>
            <h6>Saat Mengunggah File Lampiran, Pastikan File Lampiran Berupa (jpg/pdf) Dengan Ukuran Masksmal 2MB/File</h6>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\desa-plaosan-ta\resources\views/adminDashboard/lampiran/LampiranKosong.blade.php ENDPATH**/ ?>