
<?php $__env->startSection('wargaContent'); ?>
<main class="col-md-0 ms-sm-auto col-lg-10 px-md-4 mt-3">
  <div>
  </div>
<div>
    <h2>Daftar Pengaduan Saya</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#createModal">Buat Pengaduan</button>
    <br>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Judul</th>
                <th>Isi</th>
                <th>Status</th>
                <th>Tanggal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pengaduans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p->nama); ?></td>
                <td><?php echo e($p->judul); ?></td>
                <td><?php echo e($p->isi); ?></td>
                <td><?php echo e(ucfirst($p->status)); ?></td>
                <td><?php echo e($p->created_at->format('d-m-Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- Modal Create -->
<div class="modal fade" id="createModal" tabindex="-1" aria-labelledby="createModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createModalLabel">Buat Pengaduan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(url('/warga/pengaduan/ajukan')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
          <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" required maxlength="100">
          </div>
          <div class="mb-3">
            <label for="judul" class="form-label">Judul</label>
            <input type="text" class="form-control" id="judul" name="judul" required maxlength="150">
          </div>
          <div class="mb-3">
            <label for="isi" class="form-label">Isi Pengaduan</label>
            <textarea class="form-control" id="isi" name="isi" rows="3" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">Kirim</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/mainWarga', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web-desa-plaosan-ta-copy\resources\views/warga/pengaduan/index.blade.php ENDPATH**/ ?>