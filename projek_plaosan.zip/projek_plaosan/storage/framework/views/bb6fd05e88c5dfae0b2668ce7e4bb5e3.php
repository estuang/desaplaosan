


<?php $__env->startSection('wargaContent'); ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo e($title ?? 'Ajukan Surat Keterangan'); ?></h1>
    </div>
    <div class="card" style="width: 100%; background-color: white; padding: 20px">
        <div class="card-body">
            <form action="<?php echo e(route('warga.surat-keterangan.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="kategori" class="form-label"><b>Kategori Surat Keterangan</b></label>
                    <select class="form-select <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kategori" id="kategori" required>
                        <option value="" selected disabled>Pilih Kategori Surat</option>
                        <option value="Surat Keterangan Domisili">Surat Keterangan Domisili</option>
                        <option value="Surat Keterangan Tidak Mampu">Surat Keterangan Tidak Mampu</option>
                        <!--<option value="Surat Pengantar">Surat Pengantar</option>-->
                        <option value="Surat Keterangan Usaha">Surat Keterangan Usaha</option>
                        <!--<option value="Surat Keterangan Kelahiran">Surat Keterangan Kelahiran</option>-->
                        <!--<option value="Surat Keterangan Kematian">Surat Keterangan Kematian</option>-->
                        <option value="Surat Izin Acara">Surat Izin Acara</option>
                        <!--<option value="Surat Keterangan Belum Menikah">Surat Keterangan Belum Menikah</option>-->
                        <!--<option value="Surat Keterangan Pindah">Surat Keterangan Pindah</option>-->
                    </select>
                    <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label for="keterangan" class="form-label"><b>Keterangan Tambahan</b> <small class="text-muted">(Opsional)</small></label>
                    <textarea name="keterangan" id="keterangan" class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" placeholder="Tulis keterangan tambahan jika diperlukan..."></textarea>
                    <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary">Ajukan Surat</button>
                </div>
            </form>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainWarga', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/desaplao/public_html/resources/views/wargaDashboard/surat-keterangan/create.blade.php ENDPATH**/ ?>