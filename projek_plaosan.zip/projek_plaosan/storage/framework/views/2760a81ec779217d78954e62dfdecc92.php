<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('../all/allCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Custom styles for this template -->
    <link href="/css/signin.css" rel="stylesheet">
    <title><?php echo e($title); ?></title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous" />

    <!-- font awesome  -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous" />

</head>

<body class="text-center">
    <?php echo $__env->make('../all/allScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <main class="form-signin w-100 m-auto">
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('success')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
        <div class="alert alert-error alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('error')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <form action="/register" method="POST">
            <?php echo csrf_field(); ?>

            <div class="d-flex justify-content-center px-2"><img src="<?php echo e(asset('sides.png')); ?>" id="foto" alt="Logo" height="120px" /></div>
            <h1 class="h3 mb-3 fw-normal"><b>Buat Akun</b></h1>
            <p class="text-muted" style="font-size: 12px; margin-top: -8px;">Masukan Data Yang Diperlukan</p>
            <div class="form-group">
                <input style="height: 55px" type="text" class="form-control" id="nik" name="nik" placeholder="NIK" autocomplete="off" required>
                <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p style="text-align: left"><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <input style="height: 55px" type="text" class="form-control" id="name" name="name" placeholder="Nama Lengkap" autocomplete="off" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p style="text-align: left"><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <input style="height: 55px" type="text" class="form-control" id="userName" name="userName" placeholder="Username" autocomplete="off" required>
                <?php $__errorArgs = ['userName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p style="text-align: left"><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <input style="height: 55px" type="text" class="form-control" id="email" name="email" placeholder="Email" autocomplete="off" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p style="text-align: left"><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div>
                <script>
                    function password_show_hide() {
                        var x = document.getElementById("password");
                        var show_eye = document.getElementById("show_eye");
                        var hide_eye = document.getElementById("hide_eye");
                        hide_eye.classList.remove("d-none");
                        if (x.type === "password") {
                            x.type = "text";
                            show_eye.style.display = "none";
                            hide_eye.style.display = "block";
                        } else {
                            x.type = "password";
                            show_eye.style.display = "block";
                            hide_eye.style.display = "none";
                        }
                    }
                </script>
                <div class="input-group mb-3">
                    <input style="height: 55px" name="password" type="password" class="input form-control" id="password" placeholder="password" required="true" aria-label="password" aria-describedby="basic-addon1" autocomplete="off" required />

                    <div class="input-group-append" style="height: 55px">
                        <span class="input-group-text" onclick="password_show_hide();">
                            <i class="fas fa-eye" id="show_eye"></i>
                            <i class="fas fa-eye-slash d-none" id="hide_eye"></i>
                        </span>
                    </div>
                </div>
            </div>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="syarat" name="syarat" required>
                <label class="form-check-label" for="exampleCheck1">Saya telah membaca, memahami dan menyetujui syarat dan ketentuan pengguna layanan website ini</label>
                <?php $__errorArgs = ['syarat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <p style="text-align: left"><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button class="w-100 btn btn-lg btn-success" type="submit"><b>Register</b></button>

            <p>
                Click <a href="<?php echo e(url('/login')); ?>">disini</a> jika anda sudah punya akun.
            </p>
            <p class="mt-4">
                Kembali ke <a href="<?php echo e(url('/welcome')); ?>" class="text-yellow-500 hover:text-yellow-700">Halaman Awal</a>.
              </p>
              
        </form>
    </main>
</body>

</html><?php /**PATH C:\laragon\www\web-desa-plaosan-ta\resources\views/adminDashboard/register.blade.php ENDPATH**/ ?>