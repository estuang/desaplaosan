<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('../all/allCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Custom styles for this template -->
    <link href="/css/signin.css" rel="stylesheet">
    <title><?php echo e($title); ?></title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous" />

    <!-- font awesome  -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous" />

</head>

<body class="text-center">
    <?php echo $__env->make('../all/allScript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <main class="form-signin w-65 m-auto">
        <?php if(session()->has('loginError')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('loginError')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('success')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <form action="/authenticate" method="POST">
            <?php echo csrf_field(); ?>

            <div class="d-flex justify-content-center px-2"><img src="<?php echo e(asset('sides.png')); ?>" id="foto" alt="Logo" height="192px" /></div>
            <h1 class="h3 mb-3 fw-normal"><b>Sign in to Your Acount</b></h1>
            <p class="text-muted" style="font-size: 12px; margin-top: -4px;">Silakan masukan Username dan Password anda</p>

            <div class="form-group">
                <input style="height: 55px" type="text" class="form-control" id="userName" name="userName" placeholder="Username" autocomplete="off">
            </div>
            

            <div>
                <script>
                    function password_show_hide() {
                        var x = document.getElementById("password");
                        var show_eye = document.getElementById("show_eye");
                        var hide_eye = document.getElementById("hide_eye");
                        hide_eye.classList.remove("d-none");
                        if (x.type === "password") {
                            x.type = "text";
                            show_eye.style.display = "none";
                            hide_eye.style.display = "block";
                        } else {
                            x.type = "password";
                            show_eye.style.display = "block";
                            hide_eye.style.display = "none";
                        }
                    }
                </script>
                <div class="input-group mb-3">
                    <input style="height: 55px" name="password" type="password" class="input form-control" id="password" placeholder="password" required="true" aria-label="password" aria-describedby="basic-addon1" autocomplete="off" />

                    <div class="input-group-append" style="height: 55px">
                        <span class="input-group-text" onclick="password_show_hide();">
                            <i class="fas fa-eye" id="show_eye"></i>
                            <i class="fas fa-eye-slash d-none" id="hide_eye"></i>
                        </span>
                    </div>
                </div>
            </div>
            <button class="w-100 btn btn-lg btn-success" type="submit"><b>Sign in</b></button>

            <p>
                Click <a href="<?php echo e(route('register')); ?>">disini</a> jika anda belum punya akun?
            </p>
            <p class="mt-4">
                Kembali ke <a href="<?php echo e(url('/welcome')); ?>" class="text-yellow-500 hover:text-yellow-700">Halaman Awal</a>.
              </p>
        </form>
    </main>
</body>

</html><?php /**PATH /home/desaplao/public_html/resources/views/adminDashboard/login.blade.php ENDPATH**/ ?>