


<?php $__env->startSection('wargaContent'); ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo e($title ?? 'Edit Pengajuan Surat Keterangan'); ?></h1>
    </div>
    <div class="card" style="width: 100%; background-color: white; padding: 20px">
        <div class="card-body">
            <form action="<?php echo e(route('warga.surat-keterangan.update', $surat->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                    <label for="kategori" class="form-label"><b>Kategori Surat Keterangan</b></label>
                    <select class="form-select <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kategori" id="kategori" required>
                        <option value="" disabled>Pilih Kategori Surat</option>
                        <option value="Surat Keterangan Domisili" <?php echo e($surat->kategori == 'Surat Keterangan Domisili' ? 'selected' : ''); ?>>Surat Keterangan Domisili</option>
                        <option value="Surat Keterangan Tidak Mampu" <?php echo e($surat->kategori == 'Surat Keterangan Tidak Mampu' ? 'selected' : ''); ?>>Surat Keterangan Tidak Mampu</option>
                        <option value="Surat Pengantar" <?php echo e($surat->kategori == 'Surat Pengantar' ? 'selected' : ''); ?>>Surat Pengantar</option>
                        <option value="Surat Keterangan Usaha" <?php echo e($surat->kategori == 'Surat Keterangan Usaha' ? 'selected' : ''); ?>>Surat Keterangan Usaha</option>
                        <option value="Surat Keterangan Kelahiran" <?php echo e($surat->kategori == 'Surat Keterangan Kelahiran' ? 'selected' : ''); ?>>Surat Keterangan Kelahiran</option>
                        <option value="Surat Keterangan Kematian" <?php echo e($surat->kategori == 'Surat Keterangan Kematian' ? 'selected' : ''); ?>>Surat Keterangan Kematian</option>
                        <option value="Surat Izin Acara" <?php echo e($surat->kategori == 'Surat Izin Acara' ? 'selected' : ''); ?>>Surat Izin Acara</option>
                        <option value="Surat Keterangan Belum Menikah" <?php echo e($surat->kategori == 'Surat Keterangan Belum Menikah' ? 'selected' : ''); ?>>Surat Keterangan Belum Menikah</option>
                        <option value="Surat Keterangan Pindah" <?php echo e($surat->kategori == 'Surat Keterangan Pindah' ? 'selected' : ''); ?>>Surat Keterangan Pindah</option>
                    </select>
                    <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label for="keterangan" class="form-label"><b>Keterangan Tambahan</b> <small class="text-muted">(Opsional)</small></label>
                    <textarea name="keterangan" id="keterangan" class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" placeholder="Tulis keterangan tambahan jika diperlukan..."><?php echo e(old('keterangan', $surat->keterangan_warga ?? $surat->keterangan)); ?></textarea>
                    <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary">Update Surat</button>
                </div>
            </form>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainWarga', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web-desa-plaosan-ta-copy-Copy\resources\views/wargaDashboard/surat-keterangan/edit.blade.php ENDPATH**/ ?>