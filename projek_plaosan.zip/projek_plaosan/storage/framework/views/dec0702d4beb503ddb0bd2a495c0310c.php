

<?php $__env->startSection('adminContent'); ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5">
    <div class="col-md-3 mb-5">
        <h3><a href="" class="text-black">DASHBOARD</a></h3>
    </div>
    <div class="row">
        <?php if(session()->has('loginSuccess')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('loginSuccess')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <style>
            .mainMenu:hover {
                background-color: gainsboro
            }
        </style>
        <div class="col-md-3 mb-4">
            <div class="col-md-3 mb-4">
                <div class="card d-inline-flex mainMenu" style="width: 16rem; padding: 12px;  border-left: 5px solid indigo">
                    <a href="<?php echo e(route('data-penduduk')); ?>" style="text-decoration: none; color: black">
                        <div class="d-flex">
                            <div style="width: 12rem">
                                <h6 style="color: indigo">Jumlah Penduduk</h6>
                                <h4><?php echo e($jumlahMasyarakat); ?> Penduduk</h4>
                            </div>
                            <div style="width: 4rem; ">
                                <h1><span style="color: black; vertical-align: middle" class="bi bi-people"></span></h1>
                            </div>
                        </div>
                        <div class="card-footer border bg-transparent" style="width: 100%">View Details</div>
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card d-inline-flex mainMenu" style="width: 16rem; padding: 12px;  border-left: 5px solid #1746a2">
                <a href="surat-keterangan-status" style="text-decoration: none; color: black">
                    <div class="d-flex">
                        <div style="width: 12rem">
                            <h6 style="color: #1746a2">Jumlah Pengajuan Surat</h6>
                            <h5><?php echo e($jumlahS); ?> Surat Keterangan</h5>
                        </div>
                        <div style="width: 4rem; ">
                            <h1><span style="color: black; vertical-align: middle" class="bi bi-file-earmark-text"></span></h1>
                        </div>
                    </div>
                    <div class="card-footer border bg-transparent" style="width: 100%">View Details</div>
                </a>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card d-inline-flex mainMenu" style="width: 16rem; padding: 12px;  border-left: 5px solid #f0ad4e">
                <a href="<?php echo e(route('admin.pengaduan.index')); ?>" style="text-decoration: none; color: black">
                    <div class="d-flex">
                        <div style="width: 12rem">
                            <h6 style="color: #f0ad4e">Jumlah Pengaduan</h6>
                            <h5><?php echo e($jumlahPengaduan); ?> Pengaduan</h5>
                        </div>
                        <div style="width: 4rem; ">
                            <h1><span style="color: black; vertical-align: middle" class="bi bi-file-earmark-plus"></span></h1>
                        </div>
                    </div>
                    <div class="card-footer border bg-transparent" style="width: 100%">View Details</div>
                </a>
            </div>

    </div>
          

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web-desa-plaosan-ta-copy-Copy\resources\views/adminDashboard/index.blade.php ENDPATH**/ ?>