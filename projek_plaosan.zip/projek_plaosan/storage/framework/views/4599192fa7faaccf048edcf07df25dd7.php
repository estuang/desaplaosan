<header class="navbar navbar-dark sticky-top flex-md-nowrap p-0 shadow" style="background-color: #006029">
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="w-100" style="vertical-align: middle">
        <h5 style="text-align: center; vertical-align: middle; color: white; text-transform: uppercase">SISTEM MANAJEMEN LAYANAN MASYARAKAT DESA PLAOSAN</h5>
    </div>

</header><?php /**PATH D:\web-desa-plaosan-ta-copy-Copy\resources\views////layout/warga/navbar.blade.php ENDPATH**/ ?>