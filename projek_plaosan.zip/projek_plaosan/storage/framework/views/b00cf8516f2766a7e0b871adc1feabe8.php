

<?php $__env->startSection('adminContent'); ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo e($title); ?></h1>
    </div>
    <div class="card" style="width: 100%; height: 100%; background-color: white; padding: 20px">
        <?php if(session()->has('successUpdatedMasyarakat')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successUpdatedMasyarakat')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session()->has('successCreatedMasyarakat')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successCreatedMasyarakat')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session()->has('successDeletedMasyarakat')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successDeletedMasyarakat')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session()->has('successDeletedAllData')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('successDeletedAllData')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>


        <div>
            <div class="d-flex">

                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#cretaeDataMasyarakat" style="margin-right: 15px">Tambah Penduduk</button>
                <form action="/data-penduduk" method="GET" style="margin-left: 40%">

                    <input type="text" id="cari" name="cari" placeholder="Cari NIK/No KK/Nama">
                    <button type="submit" class="btn btn-success">Cari</button>
                </form>
            </div>


            <!-- Modal create-->
            <div class="modal fade" id="cretaeDataMasyarakat" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="cretaeDataMasyarakatLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="cretaeDataMasyarakatLabel">Tambah Penduduk</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form action="<?php echo e(route('data-penduduk/store')); ?>" method="post" id="formTambahPenduduk">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <!-- Section Navigation -->
                                <ul class="nav nav-tabs mb-3" id="pendudukTab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="akun-tab" data-bs-toggle="tab" data-bs-target="#akun" type="button" role="tab" aria-controls="akun" aria-selected="true">Akun</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="data-tab" data-bs-toggle="tab" data-bs-target="#data" type="button" role="tab" aria-controls="data" aria-selected="false">Data Penduduk</button>
                                    </li>
                                </ul>
                                <div class="tab-content" id="pendudukTabContent">
                                    <!-- Section Akun -->
                                    <div class="tab-pane fade show active" id="akun" role="tabpanel" aria-labelledby="akun-tab">
                                        <div class="mb-3">
                                            <label for="alamat" class="form-label"><b>Alamat</b></label>
                                            <input type="text" name="alamat" id="alamat" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('alamat')); ?>" autocomplete="off" placeholder="Input Alamat">
                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="userName" class="form-label"><b>Username</b></label>
                                            <input type="text" name="userName" id="userName" class="form-control <?php $__errorArgs = ['userName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('userName')); ?>" autocomplete="off" placeholder="Input Username">
                                            <?php $__errorArgs = ['userName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="password" class="form-label"><b>Password</b></label>
                                            <input type="password" name="password" id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="Input Password">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="role" class="form-label"><b>Role</b></label>
                                            <select class="form-select" name="role" id="role">
                                                <option value="masyarakat" selected>Masyarakat</option>
                                                <option value="admin">Admin</option>
                                            </select>
                                        </div>
                                        <div class="d-flex justify-content-end">
                                            <button type="button" class="btn btn-primary" id="nextSection">Selanjutnya</button>
                                        </div>
                                    </div>
                                    <!-- Section Data Penduduk -->
                                    <div class="tab-pane fade" id="data" role="tabpanel" aria-labelledby="data-tab">
                                        <!-- Seluruh field data penduduk seperti sebelumnya -->
                                        <div class="mb-3">
                                            <label for="nik" class="form-label"><b>NIK</b></label>
                                            <input type="text" name="nik" id="nik" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('nik')); ?>" autocomplete="off" placeholder="Input NIK Penduduk">
                                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="nama" class="form-label"><b>Nama Penduduk</b></label>
                                            <input type="text" name="nama" id="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('nama')); ?>" autocomplete="off" placeholder="Input Nama Penduduk">
                                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="no_kk" class="form-label"><b>No KK</b></label>
                                            <input type="text" name="no_kk" id="no_kk" class="form-control <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('no_kk')); ?>" autocomplete="off" placeholder="Input Nomor KK Penduduk">
                                            <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group row mb-3">
                                            <div class="col-sm-6">
                                                <label for="rt" class="form-label"><b>RT</b></label>
                                                <input type="text" name="rt" id="rt" class="form-control <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('rt')); ?>" autocomplete="off" placeholder="Input rt">
                                                <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <p style="text-align: left"><?php echo e($message); ?></p>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="rw" class="form-label"><b>RW</b></label>
                                                <input type="text" name="rw" id="rw" class="form-control <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('rw')); ?>" autocomplete="off" placeholder="Input rw">
                                                <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <p style="text-align: left"><?php echo e($message); ?></p>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="jk" class="form-label"><b>Jenis Kelamin</b></label>
                                            <select class="form-select" name="jk" id="jk">
                                                <option value="" selected>Silakan Pilih Jenis Kelamin</option>
                                                <option value="Laki-Laki">Laki-Laki</option>
                                                <option value="Perempuan">Perempuan</option>
                                            </select>
                                        </div>
                                        <div class="form-group row mb-3">
                                            <div class="col-sm-6">
                                                <label for="tempat_lahir" class="form-label"><b>Tempat lahir</b></label>
                                                <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('tempat_lahir')); ?>" autocomplete="off" placeholder="Input Tempat Lahir">
                                                <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <p style="text-align: left"><?php echo e($message); ?></p>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="tgl_lahir" class="form-label"><b>Tanggal Lahir</b></label>
                                                <input type="date" name="tgl_lahir" id="tgl_lahir" class="form-control <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('tgl_lahir')); ?>" autocomplete="off" placeholder="Input tgl Lahir">
                                                <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <p style="text-align: left"><?php echo e($message); ?></p>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="wn" class="form-label"><b>Warga Negara</b></label>
                                            <select class="form-select" name="wn" id="wn">
                                                <option value="" selected>Silakan Pilih Jenis Warga Negara</option>
                                                <option value="WNI">WNI</option>
                                                <option value="WNA">WNA</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="kebangsaan" class="form-label"><b>Kebangsaan</b></label>
                                            <input type="text" name="kebangsaan" id="kebangsaan" class="form-control <?php $__errorArgs = ['kebangsaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('kebangsaan')); ?>" autocomplete="off" placeholder="Input Kebangsaan">
                                            <?php $__errorArgs = ['kebangsaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="agama" class="form-label"><b>Agama</b></label>
                                            <select class="form-select" name="agama" id="agama">
                                                <option value="" selected>Silakan Pilih Agama</option>
                                                <option value="Islam">Islam</option>
                                                <option value="Kristen">Kristen</option>
                                                <option value="Katolik">Katolik</option>
                                                <option value="Budha">Budha</option>
                                                <option value="Konghucu">Konghucu</option>
                                                <option value="Hindu">Hindu</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="pekerjaan" class="form-label"><b>Pekerjaan</b></label>
                                            <input type="text" name="pekerjaan" id="pekerjaan" class="form-control <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('pekerjaan')); ?>" autocomplete="off" placeholder="Input pekerjaan">
                                            <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="pendidikan" class="form-label"><b>Pendidikan</b></label>
                                            <input type="text" name="pendidikan" id="pendidikan" class="form-control <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('pendidikan')); ?>" autocomplete="off" placeholder="Input pendidikan">
                                            <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="sts_kawin" class="form-label"><b>Status Kawin</b></label>
                                            <select class="form-select" name="sts_kawin" id="sts_kawin">
                                                <option value="" selected>Silakan Pilih Status Kawin</option>
                                                <option value="Kawin">Kawin</option>
                                                <option value="Belum Kawin">Belum Kawin</option>
                                                <option value="Cerai Hidup">Cerai Hidup</option>
                                                <option value="Cerai Mati">Cerai Mati</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="sts_penduduk" class="form-label"><b>Status Penduduk</b></label>
                                            <select class="form-select" name="sts_penduduk" id="sts_penduduk">
                                                <option value="" selected>Silakan Pilih Status Penduduk</option>
                                                <option value="Warga Baru Menunggu Verifikasi">Warga Baru Menunggu Verifikasi</option>
                                                <option value="Meninggal">Meninggal</option>
                                                <option value="Tinggal">Tinggal</option>
                                                <option value="Pindah Keluar">Pindah Keluar</option>
                                                <option value="Warga Pindah Menunggu Verifikasi">Warga Pindah Menunggu Verifikasi</option>
                                                <option value="Warga Meninggal Menunggu Verifikasi">Warga Meninggal Menunggu Verifikasi</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="sts_dalam_kk" class="form-label"><b>Status Dalam KK</b></label>
                                            <select class="form-select" name="sts_dalam_kk" id="sts_dalam_kk">
                                                <option value="" selected>Silakan Pilih Status Dalam KK</option>
                                                <option value="Anak">Anak</option>
                                                <option value="Kepala_Keluarga">Kepala Keluarga</option>
                                                <option value="Suami">Suami</option>
                                                <option value="Istri">Istri</option>
                                                <option value="orang_lain">Orang Lain</option>
                                            </select>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <button type="button" class="btn btn-secondary" id="prevSection">Sebelumnya</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table" style="text-align: left; color: black">
                    <tr>
                        <th>No</th>
                        <th>NIK</th>
                        <th>NAMA</th>
                        <th>NoKK</th>
                        <th>Padukuhan</th>
                        <th>RT</th>
                        <th>RW</th>
                        <th>Jenis Kelamin</th>
                        <th>Tempat Lahir</th>
                        <th>Status</th>
                        <th style="text-align: center">Action</th>
                    </tr>
                    <?php $__currentLoopData = $masyarakat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="width: 100%">
                        <td style="vertical-align: middle; width: 5%; "><?php echo e($index + $masyarakat->firstItem()); ?></td>
                        <td style="vertical-align: middle;  "><?php echo substr($item->nik,0,4). str_repeat('*', 16); ?></td>
                        <td style="vertical-align: middle;  "><?php echo e($item->nama); ?></td>
                        <td style="vertical-align: middle;  "><?php echo substr($item->no_kk,0,4). str_repeat('*', 16); ?></td>
                        <td style="vertical-align: middle;  "><?php echo e($item->padukuhan); ?></td>
                        <td style="vertical-align: middle;  "><?php echo e($item->rt); ?></td>
                        <td style="vertical-align: middle;  "><?php echo e($item->rw); ?></td>
                        <td style="vertical-align: middle;  "><?php echo e($item->jk); ?></td>
                        <td style="vertical-align: middle;  "><?php echo e($item->tempat_lahir); ?></td>
                        <td style="vertical-align: middle;  "><?php echo e($item->sts_penduduk); ?></td>
                        <td style="text-align: center;  ">
                            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editDataMasyarakat<?php echo e($item->nik); ?>">Edit</button>
                        </td>
                    </tr>

                    <!-- Modal delete-->
                    <div class="modal fade" id="staticBackdrop<?php echo e($item->nik); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Delete Data Penduduk</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <p>Apakah anda yakin untuk menghapus data <b><?php echo e($item->nama); ?></b></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                    <form action="<?php echo e(route('data-penduduk', $item->nik)); ?>" method="post">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Deleted</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal edit-->
                    <div class="modal fade" id="editDataMasyarakat<?php echo e($item->nik); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="editDataMasyarakatLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="editDataMasyarakatLabel">Edit Data Penduduk</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="<?php echo e(route('data-penduduk',$item->nik)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">

                                        <div class="mb-3">
                                            <label for="nik" class="form-label"><b>NIK</b></label>

                                            <input type="text" name="nik" id="nik" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->nik); ?>" autocomplete="off" placeholder="Input NIK Penduduk">

                                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label for="nama" class="form-label"><b>Nama Penduduk</b></label>

                                            <input type="text" name="nama" id="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->nama); ?>" autocomplete="off" placeholder="Input Nama Penduduk">

                                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label for="no_kk" class="form-label"><b>No KK</b></label>

                                            <input type="text" name="no_kk" id="no_kk" class="form-control <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->no_kk); ?>" autocomplete="off" placeholder="Input Nomor KK Penduduk">

                                            <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <div class="col-sm-6">
                                                <label for="rt" class="form-label"><b>RT</b></label>

                                                <input type="text" name="rt" id="rt" class="form-control <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->rt); ?>" autocomplete="off" placeholder="Input rt">

                                                <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <p style="text-align: left"><?php echo e($message); ?></p>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="rw" class="form-label"><b>RW</b></label>

                                                <input type="text" name="rw" id="rw" class="form-control <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->rw); ?>" autocomplete="off" placeholder="Input rw">

                                                <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <p style="text-align: left"><?php echo e($message); ?></p>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <label for="jk" class="form-label"><b>Jenis Kelamin</b></label>

                                            <select class="form-select" name="jk" id="jk">
                                                <option value="" selected>Silakan Pilih Jenis Kelamin</option>
                                                <option value="Laki-Laki" <?php echo e($item->jk == 'Laki-Laki' ? 'selected' : ''); ?>>Laki-Laki</option>
                                                <option value="Perempuan" <?php echo e($item->jk == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                                            </select>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <div class="col-sm-6">
                                                <label for="tempat_lahir" class="form-label"><b>Tempat lahir</b></label>

                                                <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->tempat_lahir); ?>" autocomplete="off" placeholder="Input Tempat Lahir">

                                                <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <p style="text-align: left"><?php echo e($message); ?></p>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="tgl_lahir" class="form-label"><b>Tanggal Lahir</b></label>

                                                <input type="date" name="tgl_lahir" id="tgl_lahir" class="form-control <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->tgl_lahir); ?>" autocomplete="off" placeholder="Input tgl Lahir">

                                                <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <p style="text-align: left"><?php echo e($message); ?></p>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="wn" class="form-label"><b>Warga Negara</b></label>

                                            <select class="form-select" name="wn" id="wn">
                                                <option value="">Silakan Pilih Jenis Warga Negara</option>
                                                <?php if($item->wn==="WNA"): ?>
                                                <option name="wn" id="wn" value="WNI">WNI</option>
                                                <option name="wn" id="wn" value="WNA" selected>WNA</option>
                                                <?php elseif($item->wn==="WNI"): ?>
                                                <option name="wn" id="wn" value="WNI" selected>WNI</option>
                                                <option name="wn" id="wn" value="WNA">WNA</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="agama" class="form-label"><b>Agama</b></label>

                                            <input type="text" name="agama" id="agama" class="form-control <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->agama); ?>" autocomplete="off" placeholder="Input agama">

                                            <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label for="pekerjaan" class="form-label"><b>Pekerjaan</b></label>

                                            <input type="text" name="pekerjaan" id="pekerjaan" class="form-control <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->pekerjaan); ?>" autocomplete="off" placeholder="Input pekerjaan">

                                            <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label for="pendidikan" class="form-label"><b>Pendidikan</b></label>

                                            <input type="text" name="pendidikan" id="pendidikan" class="form-control <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->pendidikan); ?>" autocomplete="off" placeholder="Input pendidikan">

                                            <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label for="sts_kawin" class="form-label"><b>Status Kawin</b></label>

                                            <select class="form-select" name="sts_kawin" id="sts_kawin">
                                                <option value="" <?php echo e($item->sts_kawin == '' ? 'selected' : ''); ?>>Silakan Pilih Status Kawin</option>
                                                <option value="Kawin" <?php echo e($item->sts_kawin == 'Kawin' ? 'selected' : ''); ?>>Kawin</option>
                                                <option value="Belum Kawin" <?php echo e($item->sts_kawin == 'Belum Kawin' ? 'selected' : ''); ?>>Belum Kawin</option>
                                                <option value="Cerai Hidup" <?php echo e($item->sts_kawin == 'Cerai Hidup' ? 'selected' : ''); ?>>Cerai Hidup</option>
                                                <option value="Cerai Mati" <?php echo e($item->sts_kawin == 'Cerai Mati' ? 'selected' : ''); ?>>Cerai Mati</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="sts_penduduk" class="form-label"><b>Status Penduduk</b></label>
                                            <select class="form-select" name="sts_penduduk" id="sts_penduduk">
                                                <option value="" <?php echo e($item->sts_penduduk == '' ? 'selected' : ''); ?>>Silakan Pilih Status Penduduk</option>
                                                <option value="Warga Baru Menunggu Verifikasi" <?php echo e($item->sts_penduduk == 'Warga Baru Menunggu Verifikasi' ? 'selected' : ''); ?>>Warga Baru Menunggu Verifikasi</option>
                                                <option value="Meninggal" <?php echo e($item->sts_penduduk == 'Meninggal' ? 'selected' : ''); ?>>Meninggal</option>
                                                <option value="Tinggal" <?php echo e($item->sts_penduduk == 'Tinggal' ? 'selected' : ''); ?>>Tinggal</option>
                                                <option value="Pindah Keluar" <?php echo e($item->sts_penduduk == 'Pindah Keluar' ? 'selected' : ''); ?>>Pindah Keluar</option>
                                                <option value="Warga Pindah Menunggu Verifikasi" <?php echo e($item->sts_penduduk == 'Warga Pindah Menunggu Verifikasi' ? 'selected' : ''); ?>>Warga Pindah Menunggu Verifikasi</option>
                                                <option value="Warga Meninggal Menunggu Verifikasi" <?php echo e($item->sts_penduduk == 'Warga Meninggal Menunggu Verifikasi' ? 'selected' : ''); ?>>Warga Meninggal Menunggu Verifikasi</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="sts_dalam_kk" class="form-label"><b>Status Dalam KK</b></label>

                                            <select class="form-select" name="sts_dalam_kk" id="sts_dalam_kk">
                                                <option value="" <?php echo e($item->sts_dalam_kk == '' ? 'selected' : ''); ?>>Silakan Pilih Status Penduduk</option>
                                                <option value="Kepala Keluarga" <?php echo e($item->sts_dalam_kk == 'Kepala Keluarga' ? 'selected' : ''); ?>>Kepala Keluarga</option>
                                                <option value="Istri" <?php echo e($item->sts_dalam_kk == 'Istri' ? 'selected' : ''); ?>>Istri</option>
                                                <option value="Anak" <?php echo e($item->sts_dalam_kk == 'Anak' ? 'selected' : ''); ?>>Anak</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Modal tambah keluarga-->
                    <div class="modal fade" id="tambahKel<?php echo e($item->nik); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="tambahKelLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="editDataMasyarakatLabel">Tambah Data Keluarga</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="<?php echo e(route('data-penduduk/store',$item->nik)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">

                                        <div class="mb-3">
                                            <label for="nik" class="form-label"><b>NIK</b></label>

                                            <select class="form-select" name="nik" id="nik">
                                                <option name="nik" id="nik" value="" selected>Silakan Pilih NIK</option>
                                                <?php $__currentLoopData = $pendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option name="nik" id="nik" value="<?php echo e($penduduk->nik); ?>"><?php echo e($penduduk->nik); ?> | <?php echo e($penduduk->nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="no_kk" class="form-label"><b>No KK</b></label>

                                            <input type="text" name="no_kk" id="no_kk" class="form-control <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->no_kk); ?>" autocomplete="off" placeholder="Input Nomor KK Penduduk">

                                            <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3">
                                            <label for="sts_keluarga" class="form-label"><b>Status Keluarga</b></label>

                                            <input type="text" name="sts_keluarga" id="sts_keluarga" class="form-control <?php $__errorArgs = ['sts_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e($item->sts_keluarga); ?>" autocomplete="off" placeholder="Input Status Keluarga">

                                            <?php $__errorArgs = ['sts_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <p style="text-align: left"><?php echo e($message); ?></p>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <div class="d-flex justify-content-between mb-3">
                    <?php echo e($masyarakat->links('layout.pagination')); ?>

                </div>
            </div>

        </div>
</main>
<?php $__env->stopSection(); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const nextBtn = document.getElementById('nextSection');
        const prevBtn = document.getElementById('prevSection');
        const akunTab = document.getElementById('akun-tab');
        const dataTab = document.getElementById('data-tab');
        nextBtn.addEventListener('click', function() {
            dataTab.click();
        });
        if (prevBtn) {
            prevBtn.addEventListener('click', function() {
                akunTab.click();
            });
        }
    });
</script>
<?php echo $__env->make('../layout/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web-desa-plaosan-ta-copy-Copy\resources\views/adminDashboard/Penduduk.blade.php ENDPATH**/ ?>