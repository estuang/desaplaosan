


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">


<link rel="stylesheet" href="/css/style.css">

<style>
    @import url('https://fonts.googleapis.com/css2?family=Oregano&display=swap');
</style>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Oregano&family=Raleway:wght@900&display=swap');
</style><?php /**PATH C:\laragon\www\web-desa-plaosan-ta-copy-Copy\resources\views////all/allCss.blade.php ENDPATH**/ ?>