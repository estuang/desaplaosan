

<?php $__env->startSection('adminContent'); ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5">
    <div class="col-md-3 mb-5">
        <h3><a href="" class="text-black">DASHBOARD</a></h3>
    </div>
    <div class="row">
        <?php if(session()->has('loginSuccess')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session('loginSuccess')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <style>
          
    
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web-desa-plaosan-ta-copy\resources\views/adminDashboard/index.blade.php ENDPATH**/ ?>